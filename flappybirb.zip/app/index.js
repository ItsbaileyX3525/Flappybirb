import * as document from "document";
import * as fs from "fs";

//to add a python feel
const print = console.log;

//load game data
function checkForFile(filename) {
  var dirIter;
  var listDir = fs.listDirSync("/private/data");
  while((dirIter = listDir.next()) && !dirIter.done) {
    if (dirIter.value === filename) {
      return true;
    }
  }
  return false;
}

if (!checkForFile("Jeabsis.txt")){
  let json_data = {
      "highScore" : 0,
      "firstTime" : true
  };
  fs.writeFileSync("save.txt", json_data, "json");
  }
//Reads data from json file so that i can save and read data :)
let gameData = fs.readFileSync("save.txt", "json");
let highScore = gameData['highScore'];
let firstTime = gameData['firstTime'];

const background = document.getElementById("backgroundImage");
const background2 = document.getElementById("backgroundImage1");
const ClickDetector = document.getElementById("ClickDetector");
const loadGameDetector = document.getElementById("Removethisshit");
const Flappybird = document.getElementById("flappyBird");
const flappyBirb = document.getElementById("Bird");
const pipe1 = document.getElementById("pipe1");
const pipe2 = document.getElementById("pipe2");
const pipe3 = document.getElementById("pipe3");
const pipe4 = document.getElementById("pipe4");
const pipe5 = document.getElementById("pipe5");
const pipe6 = document.getElementById("pipe6");
const pipe1Image = document.getElementById("pipe1Image");
const pipe2Image = document.getElementById("pipe2Image");
const pipe3Image = document.getElementById("pipe3Image");
const pipe4Image = document.getElementById("pipe4Image");
const pipe5Image = document.getElementById("pipe5Image");
const pipe6Image = document.getElementById("pipe6Image");

let fallRate=0
let globalCollisionEmitter = false
let timeouts = []
let gameUpdate
let egg
let increaseFall

if (firstTime){
background.style.display="none";
ClickDetector.style.display="none";
Flappybird.style.display="none";
flappyBirb.style.display="none";
pipe1.style.display="none";
pipe2.style.display="none";
pipe3.style.display="none";
pipe4.style.display="none";
pipe5.style.display="none";
pipe6.style.display="none";
} else {
  loadGameDetector.style.display="none";
  background2.style.display="none";
}
function RandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;;
}

function lerp(a, b, t) {
  return ((1-t)*a) + (t*b)
}
function animte(start_value, target_value, duration){
  for (var e = 0; e < timeouts.length; e++) {
    clearTimeout(timeouts[e]);
  }
  timeouts = []
for (let i=0; i<=duration*60; i+=1) {
  timeouts.push(
      egg = setTimeout(
          function anon() {
              var t = i / duration / 30
              flappyBirb.y = lerp(start_value, target_value, t)
          },
          1000*i/30
      ));
}
}

function startUp(){
  //to be called once upon game start
  pipe1.x = 280;
  pipe3.x = 380;
  pipe5.x = 480;

  pipe1.y = RandomInt(200,320)
  pipe3.y = RandomInt(200,320)
  pipe5.y = RandomInt(200,320)
}

function gameLogic() {
  // Check for collision & that
  if (
    Flappybird.x < pipe1.x + pipe1.width &&
    Flappybird.x + Flappybird.width > pipe1.x &&
    Flappybird.y < pipe1.y + pipe1.height &&
    Flappybird.y + Flappybird.height > pipe1.y ||

    Flappybird.x < pipe2.x + pipe2.width &&
    Flappybird.x + Flappybird.width > pipe2.x &&
    Flappybird.y < pipe2.y + pipe2.height &&
    Flappybird.y + Flappybird.height > pipe2.y ||

    Flappybird.x < pipe3.x + pipe3.width &&
    Flappybird.x + Flappybird.width > pipe3.x &&
    Flappybird.y < pipe3.y + pipe3.height &&
    Flappybird.y + Flappybird.height > pipe3.y ||

    Flappybird.x < pipe4.x + pipe4.width &&
    Flappybird.x + Flappybird.width > pipe4.x &&
    Flappybird.y < pipe4.y + pipe4.height &&
    Flappybird.y + Flappybird.height > pipe4.y ||

    Flappybird.x < pipe5.x + pipe5.width &&
    Flappybird.x + Flappybird.width > pipe5.x &&
    Flappybird.y < pipe5.y + pipe5.height &&
    Flappybird.y + Flappybird.height > pipe5.y ||

    Flappybird.x < pipe6.x + pipe6.width &&
    Flappybird.x + Flappybird.width > pipe6.x &&
    Flappybird.y < pipe6.y + pipe6.height &&
    Flappybird.y + Flappybird.height > pipe6.y
  ) {
    //If the bird hit a pipe end game
    globalCollisionEmitter = true
    endGame();
  } else {
    //Main game logic 
    Flappybird.y = flappyBirb.y

    pipe1Image.x = pipe1.x
    pipe1Image.y = pipe1.y

    pipe2Image.x = pipe2.x
    pipe2Image.y = pipe2.y

    pipe3Image.x = pipe3.x
    pipe3Image.y = pipe3.y

    pipe4Image.x = pipe4.x
    pipe4Image.y = pipe4.y

    pipe5Image.x = pipe5.x
    pipe5Image.y = pipe5.y

    pipe6Image.x = pipe6.x
    pipe6Image.y = pipe6.y

    pipe2.x = pipe1.x
    pipe4.x = pipe3.x
    pipe6.x = pipe5.x

    pipe2.y = pipe1.y-310
    pipe4.y = pipe3.y-310
    pipe6.y = pipe5.y-310
    
  }

}
function fallStart(){
  if (timeouts.length === 4 || timeouts.length === 0){
  
  function IncreaseFallRate(){
    flappyBirb.y += fallRate
    if (fallRate < 6){
    fallRate+=.5}
  }
  increaseFall = setInterval(IncreaseFallRate, 1000/30);
  }
}
ClickDetector.addEventListener("mousedown", (e) => {
  let fall;
  if (!globalCollisionEmitter){
  fallRate = 0;
  flappyBirb.y = animte(flappyBirb.y, flappyBirb.y-15, .05);
  clearTimeout(fall)
  clearInterval(increaseFall);
  fall = setTimeout(function () {
    fallStart();
  }, 50);
}})

function loadGame(){
  // Check for collision every 1/30th of a second
  gameUpdate = setInterval(gameLogic, 1000 / 30);

  background.style.display="inline";
  ClickDetector.style.display="inline";
  Flappybird.style.display="inline";
  flappyBirb.style.display="inline";
  pipe1.style.display="inline";
  pipe2.style.display="inline";
  pipe3.style.display="inline";
  pipe4.style.display="inline";
  pipe5.style.display="inline";
  pipe6.style.display="inline";
  loadGameDetector.style.display="none";
  background2.style.display="none";
}

function endGame(){
  clearInterval(gameUpdate);
}

loadGameDetector.addEventListener("mousedown", (e) => {
  loadGame();
  startUp();

  //save firstTime so user doesnt see promt each time
  //[code here]
})